#include "stm32f10x.h"                  // Device header
#include "LED.h"

extern uint16_t NEW;

void TIM2break_Init(u16 tay,u16 data){
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
		TIM_InternalClockConfig(TIM2);									//使用内部时钟来驱动？？？
		TIM_ClearFlag(TIM2,TIM_FLAG_Update);      			//避免刚初始化完就进入中断
//		TIM2Init.TIM_RepetitionCounter=0;				//重复计数器的值（一般是高级计数器才用）
	
	TIM_TimeBaseInitTypeDef TIM2Init;
	TIM2Init.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM2Init.TIM_CounterMode=TIM_CounterMode_Up;       //向上计数器模式
	TIM2Init.TIM_Period=tay;                           //计数器重装值
	TIM2Init.TIM_Prescaler=data;                       //计数器时钟预分频值
	TIM_TimeBaseInit(TIM2,&TIM2Init);
	
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);           //开启TIM2的更新中断
	
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);    //中断分组
	
	NVIC_InitTypeDef Init_NVIC;
	Init_NVIC.NVIC_IRQChannel=TIM2_IRQn;
	Init_NVIC.NVIC_IRQChannelCmd=ENABLE;
	Init_NVIC.NVIC_IRQChannelPreemptionPriority=2;     //抢占优先级
	Init_NVIC.NVIC_IRQChannelSubPriority=2;				     //响应优先级
	NVIC_Init(&Init_NVIC);
	
	TIM_Cmd(TIM2,ENABLE);                              //启动TIM2
}


void TIM2_IRQHandler(void){
	if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET){	
		NEW=!NEW;		
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);         //清除中断标志位
	}
}

