#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
#include "TIM.h"
#include "OLED.h"

uint16_t NEW;

/**
*定时器的溢出时间公式为 @Tout=(ARR+1)(PSC+1)/TcLK
	*ARR为计数器重装值
	*PSC为计数器的预分频值
	*TcLK为定时器的时钟值 @一般等于APB1的时钟×2
**/

int main(void){
	LED_Init();
	TIM2break_Init(4999,7199);
	while(1){
		LED_Data(NEW);
	}
}
