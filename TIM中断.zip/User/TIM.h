#ifndef __TIM_H
#define __TIM_H

void TIM2break_Init(u16 tay,u16 data);


#endif
