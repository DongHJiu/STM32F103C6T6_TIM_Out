#include "stm32f10x.h"                  // Device header


/**
  * @brief  配置串口引脚
  * @param  无
  * @retval 无
  */
void UART_Init(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1|RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIOUARTT_Init;
	GPIOUARTT_Init.GPIO_Mode=GPIO_Mode_AF_PP;             //设置复用推挽输出模式
	GPIOUARTT_Init.GPIO_Pin=GPIO_Pin_9;
	GPIOUARTT_Init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOUARTT_Init);
	
	GPIO_InitTypeDef GPIOUARTR_Init;
	GPIOUARTR_Init.GPIO_Mode=GPIO_Mode_IN_FLOATING;				//设置浮空输入模式
	GPIOUARTR_Init.GPIO_Pin=GPIO_Pin_10;
	GPIOUARTR_Init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOUARTR_Init);
	
	
	USART_InitTypeDef USART1_Init;
	USART1_Init.USART_BaudRate=9600;                      //设置波特率为9600
	USART1_Init.USART_HardwareFlowControl=USART_HardwareFlowControl_None;     //设置硬件流控制(这里设置不使用)
	USART1_Init.USART_Mode=USART_Mode_Rx|USART_Mode_Tx;   //设置发送和接受的使能 
	USART1_Init.USART_Parity=USART_Parity_No;             //设置奇偶校验(这里设置无奇偶校验)
	USART1_Init.USART_StopBits=USART_StopBits_1;          //设置停止位(这里设置停止位为1位)
	USART1_Init.USART_WordLength=USART_WordLength_8b;     //设置传输数据长度(这里设置数据长度为8位)
	USART_Init(USART1,&USART1_Init);
	
	USART_Cmd(USART1,ENABLE);                             //使能USART1
	//USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);          //打开USART1的接收中断
}

