#include "stm32f10x.h"                  // Device header


u8 TIM_data=0;               //存放溢出次数
u16 data=0;                  //存放计数器的当前值


void TIM2_Init2(void){
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIOLED_Init;
	GPIOLED_Init.GPIO_Mode=GPIO_Mode_IPD;
	GPIOLED_Init.GPIO_Pin=GPIO_Pin_0;
	GPIOLED_Init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOLED_Init);
	
	/**ARR和PSC设置的是定时时间
	*公式:定时频率=72MHZ/(PSC+1)/(ARR+1)
	*上公式中的72MHZ不知道是不是他所在的总线的频率（上网查下）
	*/
	      TIM_InternalClockConfig(TIM2);									          //使用内部时钟来驱动
	TIM_TimeBaseInitTypeDef InitPor_TIM;											 
	InitPor_TIM.TIM_ClockDivision=TIM_CKD_DIV1;								//设置时钟分割
	InitPor_TIM.TIM_CounterMode=TIM_CounterMode_Up;						//计数器向上计数模式
	InitPor_TIM.TIM_Period=10000-1;			                			//ARR自动重装器的值
	InitPor_TIM.TIM_Prescaler=7200-1;				                  //PSC预分频器的值
	TIM_TimeBaseInit(TIM2,&InitPor_TIM);							        
	
	     TIM_ClearFlag(TIM2,TIM_FLAG_Update);                			//避免刚初始化完就进入中断
	
	
   TIM_ICInitTypeDef TIM_IC_Init;
	TIM_IC_Init.TIM_Channel=TIM_Channel_1;                      //设置在通道一上面
	TIM_IC_Init.TIM_ICFilter=0x00;                              //设置输入滤波器(这里不配置滤波)
	TIM_IC_Init.TIM_ICPolarity=TIM_ICPolarity_Rising;           //设置上降沿捕获
	TIM_IC_Init.TIM_ICPrescaler=TIM_ICPSC_DIV1;                 //设置输入分频(不分频)
	TIM_IC_Init.TIM_ICSelection=TIM_ICSelection_DirectTI;       //这里选择直接映射在TI1上/IndirectTI是间接映射
	TIM_ICInit(TIM2,&TIM_IC_Init);

	TIM_ITConfig(TIM2,TIM_IT_Update|TIM_IT_CC1,ENABLE);				//使能TIM2的计数更新中断和TIM2通道一的输入捕获中断
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);           //中断优先级分组	
	NVIC_InitTypeDef Init_NVIC;
	Init_NVIC.NVIC_IRQChannel=TIM2_IRQn;
	Init_NVIC.NVIC_IRQChannelCmd=ENABLE;
	Init_NVIC.NVIC_IRQChannelPreemptionPriority=2;            //抢占优先级
	Init_NVIC.NVIC_IRQChannelSubPriority=2;				            //响应优先级
	NVIC_Init(&Init_NVIC);
	 

	TIM_Cmd(TIM2,ENABLE);                   					        //使能TIM2的功能
}


void TIM2_IRQHandler(void){
	if(TIM_GetITStatus(TIM2,TIM_IT_Update)){                       //更新中断
		if(TIM_data&0x40){
			if((TIM_data&0x3f)==0x3f){
				TIM_data|=0x80;
				data=0xffff;
			}
			else{
				TIM_data++; 
			}
		}
	}
	
	
	if(TIM_GetITStatus(TIM2,TIM_IT_CC1)){                         //输入捕获中断
		if(TIM_data&0x40){
			TIM_data|=0x80;
			data=TIM_GetCapture1(TIM2);
			TIM_OC1PolarityConfig(TIM2,TIM_ICPolarity_Rising);   //单独设置极性
			   //TIM_data=0;   这段代码主函数已经写了,但我感觉在这里写也是可以的
		}
		else{                                                                         //刚按下应该是先执行这个的
			TIM_data=0;
			data=0;
			TIM_data|=0x40;
			TIM_Cmd(TIM2,DISABLE);
			TIM_SetCounter(TIM2,0);                                 //计数器值清零
			TIM_OC1PolarityConfig(TIM2,TIM_ICPolarity_Falling);   //单独设置极性
			TIM_Cmd(TIM2,ENABLE);			
		}
	}
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update|TIM_IT_CC1);    //清除中断标志位
}
