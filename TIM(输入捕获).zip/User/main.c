#include "stm32f10x.h"                  // Device header
#include "LED.h"
#include "UART.h"
#include "Delay.h"
#include "TIM_IO.h"
#include "OLED.h"



/*A0引脚来上升沿开始捕获,捕获完成后并在OLED屏上显示出来*/
int main(void){
	 //UART_Init();
   TIM2_Init2();
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_WriteBit(GPIOB,GPIO_Pin_7,Bit_RESET);
	OLED_Init();	
while(1){
	if(TIM_data&0x80){
		//发送函数
		//USART_SendData(USART1,data);                         //USART1发送数据Data
		data=data/1000;                                        
		TIM_data=TIM_data-192;                                 //这个值最高位和次高位被用来判断了,所以他在主函数的初值是192
		OLED_ShowNum(1,1,TIM_data,1);
		OLED_ShowChar(1,2,'.');
		OLED_ShowNum(1,3,data,1);
		TIM_data=0;
	}
}
}
