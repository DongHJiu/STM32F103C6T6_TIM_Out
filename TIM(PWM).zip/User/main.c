#include "stm32f10x.h"                  // Device header
#include "PWM.h"
#include "Delay.h"

int i;

int main(void){
	TIMPWM_Init(99,719);
	while(1){
	for(i=2;i<60;i++){
		PWM_Adjust(i);
		Delay_ms(40);
	}
	for(i=60;i>2;i--){
		PWM_Adjust(i);
		Delay_ms(40);
	}	
	Delay_ms(50);
  }
}
