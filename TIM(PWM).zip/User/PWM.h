#ifndef __PWM_H
#define __PWM_H

void TIMPWM_Init(u16 FirstData,u16 SecondData);
void PWM_Adjust(uint16_t New);

#endif
