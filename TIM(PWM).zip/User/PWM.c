#include "stm32f10x.h"                  // Device header

//u16 FirstData,u16 SecondData
void TIMPWM_Init(u16 FirstData,u16 SecondData){
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIOLED_Init;
	GPIOLED_Init.GPIO_Mode=GPIO_Mode_AF_PP;                  //设置复用推挽输出
	GPIOLED_Init.GPIO_Pin=GPIO_Pin_0;
	GPIOLED_Init.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOLED_Init);
	
	
	TIM_TimeBaseInitTypeDef InitPor_TIM;											
	InitPor_TIM.TIM_ClockDivision=TIM_CKD_DIV1;								//这玩意我也不知道是啥
	InitPor_TIM.TIM_CounterMode=TIM_CounterMode_Up;						//计数器向上计数模式	
	InitPor_TIM.TIM_Period=FirstData;						              //计数器重装值
	InitPor_TIM.TIM_Prescaler=SecondData;                     //计数器时钟预分频器值	
	TIM_TimeBaseInit(TIM2,&InitPor_TIM);							
	
	
	TIM_OCInitTypeDef TIMPWM_OC1;
	TIMPWM_OC1.TIM_OCMode=TIM_OCMode_PWM2;                     //输出比较模式
	TIMPWM_OC1.TIM_OCPolarity=TIM_OCPolarity_High;             //输出有效极性(高电平有效还是低电平有效)
	TIMPWM_OC1.TIM_OutputState=TIM_OutputState_Enable;         //输出使能
	TIMPWM_OC1.TIM_Pulse=50;                                   //设置CCR寄存器的初始化值
	TIM_OC1Init(TIM2,&TIMPWM_OC1);
	
	//TIM_OCStructInit(&TIMPWM_OC1);                          ??? 
	TIM_OC1PreloadConfig(TIM2,TIM_OCPreload_Enable);          //使能通道1的预装载值
	TIM_Cmd(TIM2,ENABLE);                   				         	//启动定时器
}  

void PWM_Adjust(uint16_t New){

	TIM_SetCompare1(TIM2,New);     //单独修改CCR的值

}
